# Despliegue en Cloudflare Pages

El dashboard es un sitio **estático** (HTML + JS, sin build). Cloudflare Pages lo
sirve por su CDN global y **comprime `dashboard_data.js` con Brotli
automáticamente**: el archivo de ~8.8 MB viaja al navegador en ~1.5 MB
(reducción de ~85 %), sin cambiar una sola línea del dashboard.

## Archivos de configuración (ya incluidos en el repo)

| Archivo | Para qué sirve |
|---|---|
| `_headers` | CSP `frame-ancestors` para embeber en Teams/Office/SharePoint + cache de datos y librerías |
| `_redirects` | Fallback SPA (equivale a `navigationFallback` de Azure) |

Cloudflare Pages lee estos dos archivos desde la raíz de la publicación. No hay
`wrangler.toml` ni paso de build porque no hay compilación.

## Opción A · Integración con Git (recomendada, sin secretos)

1. Entra a **dash.cloudflare.com → Workers & Pages → Create → Pages → Connect to Git**.
2. Autoriza GitHub y elige el repo `josemartinezcomco-rgb/dashboard-powest`.
3. Configura el proyecto:
   - **Production branch:** `main`
   - **Framework preset:** `None`
   - **Build command:** *(vacío)*
   - **Build output directory:** `/`  (la raíz del repo)
4. **Save and Deploy.** Cada push a `main` (incluidos los commits diarios de
   datos) redesplegará solo, igual que hoy con Azure.
5. (Opcional) En **Custom domains** conecta tu dominio de Powest.

> Con esta opción no necesitas tokens ni secretos en GitHub.

## Opción B · GitHub Actions (si prefieres CI)

Requiere crear un API token en Cloudflare y añadir dos secretos al repo
(`CLOUDFLARE_API_TOKEN`, `CLOUDFLARE_ACCOUNT_ID`). Workflow:

```yaml
name: Deploy to Cloudflare Pages
on:
  push:
    branches: [main]
  workflow_dispatch:
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Publish to Cloudflare Pages
        uses: cloudflare/wrangler-action@v3
        with:
          apiToken: ${{ secrets.CLOUDFLARE_API_TOKEN }}
          accountId: ${{ secrets.CLOUDFLARE_ACCOUNT_ID }}
          command: pages deploy . --project-name=dashboard-powest --branch=main
```

## Verificar que Brotli funciona

Con el sitio ya en Cloudflare, en la terminal:

```bash
curl -s -H "Accept-Encoding: br" -o /dev/null -w "%{size_download} bytes\n" \
  https://<tu-sitio>.pages.dev/dashboard_data.js
```

Debe mostrar ~1.5 MB en vez de ~8.8 MB. También puedes verlo en el navegador:
DevTools → Network → `dashboard_data.js` → columna *Size* (transferido) vs
*Content* (real), y `content-encoding: br` en las Response Headers.

## Migración desde Azure (sin caídas)

- El workflow `.github/workflows/azure-static-web-apps.yml` y
  `staticwebapp.config.json` **se dejan en su lugar** mientras validas Cloudflare,
  para no tener interrupción de servicio.
- Cuando confirmes que Cloudflare sirve todo bien (incluido el embebido en
  Teams), puedes borrar ambos archivos y apuntar el dominio a Cloudflare.
